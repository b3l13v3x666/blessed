var config = {
    env: "pro",
    components_version: "1.0.3",
    shared_footer_version: "1.0.6",
    shared_header_version: "1.0.87",
    federationPageList: "all",
    openFederation: true,
    stat: {
        cookiePolicyLevel: "middle",
        cookieDefaultOnCat: "0,1,2,3:",
        cookieDomain: ".mi.co.id"
    },
    trustArcSite: "id",
    trustArcLang: "id",
    wwwSite: {
        pc: "//www.mi.co.id/id"
    },
    goSite: "//go.buy.mi.co.id/id",
    local: "id",
    buySite: {
        pc: "//buy.mi.co.id/id"
    },
    isToC: true
};
window.__LOCAL_CONFIG__ = config;
